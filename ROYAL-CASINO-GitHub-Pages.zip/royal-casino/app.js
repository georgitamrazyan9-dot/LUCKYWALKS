(() => {
  "use strict";
  const START_BALANCE = 10000;
  const STORAGE_KEY = "royalCasinoDemo_v1";
  const games = [
    {name:"Слоты",icon:"🎰",cat:"classic",label:"Классика",desc:"Три символа — один счастливый миг."},
    {name:"Рулетка",icon:"🎡",cat:"classic",label:"Классика",desc:"Испытайте удачу на колесе."},
    {name:"Блэкджек",icon:"🂡",cat:"table",label:"Карты",desc:"Наберите очки ближе к 21."},
    {name:"Кости",icon:"🎲",cat:"chance",label:"Удача",desc:"Бросок решает всё."},
    {name:"Мины",icon:"💣",cat:"chance",label:"Риск",desc:"Найдите безопасные клетки."},
    {name:"Plinko",icon:"🔻",cat:"arcade",label:"Аркада",desc:"Путь фишки к награде."},
    {name:"Покер",icon:"🃏",cat:"table",label:"Карты",desc:"Соберите свою комбинацию."},
    {name:"Дракон и тигр",icon:"🐉",cat:"table",label:"Карты",desc:"Кто окажется сильнее?"}, 
    {name:"Crash",icon:"🚀",cat:"arcade",label:"Аркада",desc:"Поймайте момент взлёта."},
    {name:"Chicken Road",icon:"🐔",cat:"arcade",label:"Аркада",desc:"Помогите цыплёнку пройти путь."},
    {name:"Скачки",icon:"🏇",cat:"chance",label:"Удача",desc:"Выберите фаворита забега."},
    {name:"Дартс",icon:"🎯",cat:"arcade",label:"Аркада",desc:"Меткость приносит очки."},
    {name:"Сундуки удачи",icon:"🧰",cat:"chance",label:"Удача",desc:"В одном из сундуков приз."},
    {name:"Орёл или решка",icon:"🪙",cat:"chance",label:"Удача",desc:"Угадайте сторону монеты."},
    {name:"Колесо фортуны",icon:"☸️",cat:"chance",label:"Удача",desc:"Крутите колесо наград."},
    {name:"Баккара",icon:"♠️",cat:"table",label:"Карты",desc:"Сравните очки двух рук."},
    {name:"Угадай число",icon:"🔢",cat:"arcade",label:"Аркада",desc:"Найдите секретное число."},
    {name:"Охота за драгоценностями",icon:"💎",cat:"arcade",label:"Аркада",desc:"Откройте сияющие камни."},
    {name:"Боулинг",icon:"🎳",cat:"arcade",label:"Аркада",desc:"Сбейте как можно больше кеглей."},
    {name:"Счастливая семёрка",icon:"🍀",cat:"classic",label:"Классика",desc:"Пусть семёрка будет вашей."}
  ];
  const leaderData = [
    ["♛","GoldLion","18 450"],["✦","LadyFortune","16 200"],["♠","RoyalAce","14 890"],["♦","LuckyFox","12 740"],["☀","SilverStar","11 300"]
  ];
  const $ = s => document.querySelector(s);
  const money = n => "₽ " + Math.floor(n).toLocaleString("ru-RU");
  let state = loadState(), activeCategory = "all", toastTimer;
  function loadState(){
    try { const s=JSON.parse(localStorage.getItem(STORAGE_KEY)); if(s && Number.isFinite(s.balance)) return {...s, history:Array.isArray(s.history)?s.history:[]}; } catch(e){}
    return {balance:START_BALANCE,history:[{type:"Стартовый баланс",amount:START_BALANCE,date:new Date().toISOString()}],lastDaily:"",wins:0,played:0};
  }
  function save(){try{localStorage.setItem(STORAGE_KEY,JSON.stringify(state));}catch(e){} updateBalance();}
  function updateBalance(){ $("#headerBalance").textContent=money(state.balance); }
  function toast(msg){const el=$("#toast");el.textContent=msg;el.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove("show"),2600);}
  function log(type,amount){state.history.unshift({type,amount,date:new Date().toISOString()});state.history=state.history.slice(0,40);save();}
  function changeBalance(amount,type){
    if(amount<0 && state.balance < -amount){toast("Недостаточно виртуальных очков.");return false;}
    state.balance=Math.max(0,state.balance+amount);log(type,amount);return true;
  }
  function renderGames(){
    const q=$("#gameSearch").value.trim().toLocaleLowerCase("ru");
    const filtered=games.map((g,i)=>({...g,id:i})).filter(g=>(activeCategory==="all"||g.cat===activeCategory)&&g.name.toLocaleLowerCase("ru").includes(q));
    $("#gameCount").textContent=filtered.length;
    $("#gamesGrid").innerHTML=filtered.length?filtered.map(g=>`<article class="game-card" style="--glow:${g.cat==="chance"?"#d7b34d24":g.cat==="arcade"?"#7b9c7224":"#d4aa4c24"}">
      <div class="game-visual"><span class="game-num">ROYAL / ${String(g.id+1).padStart(2,"0")}</span><span class="game-label">${g.label}</span><span class="game-symbol" aria-hidden="true">${g.icon}</span></div>
      <div class="game-info"><h3>${escapeHtml(g.name)}</h3><p>${escapeHtml(g.desc)}</p><button class="play-btn" data-play="${g.id}">Играть <span>↗</span></button></div></article>`).join(""):`<div class="empty-state">По вашему запросу ничего не найдено.</div>`;
    $("#gamesGrid").querySelectorAll("[data-play]").forEach(b=>b.addEventListener("click",()=>openGame(games[+b.dataset.play])));
  }
  function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
  function renderLeaders(){$("#leaderList").innerHTML=leaderData.map((p,i)=>`<div class="leader-row"><div class="rank ${i<3?"top":""}">${String(i+1).padStart(2,"0")}</div><div style="display:flex;align-items:center;gap:10px"><span class="avatar">${p[0]}</span><span class="leader-user">${p[1]}<small>${i===0?"VIP Legend":i===1?"Royal member":"Club member"}</small></span></div><div class="leader-score">${p[2]} pts</div></div>`).join("");}
  function openModal(title,html){$("#modalTitle").textContent=title;$("#modalContent").innerHTML=html;$("#modalBackdrop").hidden=false;document.body.style.overflow="hidden";}
  function closeModal(){$("#modalBackdrop").hidden=true;document.body.style.overflow="";$("#modalContent").innerHTML="";}
  function modalBalance(){return `<div class="modal-balance">Баланс: <strong>${money(state.balance)}</strong> · виртуальные очки</div>`;}
  function amountField(label="Количество очков",value=1000){return `<label class="form-label" for="amountInput">${label}</label><input class="field" id="amountInput" type="number" min="1" max="100000" step="100" value="${value}">`;}
  function openWallet(mode){
    const deposit=mode==="deposit";
    openModal(deposit?"Пополнение баланса":"Вывод виртуальных очков",`<p>${deposit?"Добавьте очки в демонстрационный кошелёк.":"Переместите виртуальные очки из игрового баланса в демонстрационный запрос на вывод."} Реальные платежи не подключены, денежная стоимость отсутствует.</p>${amountField(deposit?"Сколько добавить?":"Сколько вывести?",1000)}<div class="modal-actions"><button class="btn btn-gold" id="walletConfirm">${deposit?"Зачислить очки":"Подтвердить демо-вывод"}</button><button class="btn btn-ghost" id="cancelModal">Отмена</button></div>${modalBalance()}`);
    $("#cancelModal").onclick=closeModal;
    $("#walletConfirm").onclick=()=>{const n=Number($("#amountInput").value);if(!Number.isInteger(n)||n<1||n>100000){toast("Введите целое число от 1 до 100 000.");return;}if(deposit){changeBalance(n,"Демо-пополнение");toast(`${money(n)} виртуальных очков зачислено.`);}else{if(!changeBalance(-n,"Демо-вывод"))return;toast("Демо-запрос обработан. Реальных выплат нет.");}closeModal();};
  }
  function openProfile(){openModal("Профиль игрока",`<div class="game-stage"><div class="stage-symbol">♛</div><div class="stage-result">Royal Guest</div><div class="stage-help">Участник виртуального клуба</div></div><p>Ваш игровой профиль хранится только в этом браузере.</p><div class="daily-reward"><span>✦</span><div><small>ТЕКУЩИЙ БАЛАНС</small><strong>${money(state.balance)}</strong></div></div><p>Сыграно раундов: <b>${state.played||0}</b><br>Удачных раундов: <b>${state.wins||0}</b></p><div class="modal-actions"><button class="btn btn-gold" id="historyFromProfile">История</button><button class="btn btn-ghost" id="resetDemo">Сбросить демо</button></div>${modalBalance()}`);$("#historyFromProfile").onclick=openHistory;$("#resetDemo").onclick=()=>{if(confirm("Сбросить баланс и историю к начальным значениям?")){state={balance:START_BALANCE,history:[],lastDaily:"",wins:0,played:0};log("Сброс демо-баланса",START_BALANCE);closeModal();toast("Демо-профиль сброшен.");}};}
  function openHistory(){const rows=state.history.slice(0,12);openModal("История операций",rows.length?`<div class="history-list">${rows.map(h=>`<div class="leader-row"><div class="rank">${h.amount>0?"+":"−"}</div><div class="leader-user">${escapeHtml(h.type)}<small>${new Date(h.date).toLocaleString("ru-RU",{dateStyle:"short",timeStyle:"short"})}</small></div><div class="leader-score" style="color:${h.amount>=0?"var(--green)":"var(--red)"}">${h.amount>0?"+":""}${money(h.amount)}</div></div>`).join("")}</div><div class="modal-actions"><button class="btn btn-ghost" id="historyClose">Закрыть</button></div>${modalBalance()}`:`<p>Пока нет операций. Сыграйте в мини-игру или заберите ежедневный бонус.</p><div class="modal-actions"><button class="btn btn-gold" id="historyClose">Понятно</button></div>${modalBalance()}`);$("#historyClose").onclick=closeModal;}
  function claimDaily(){const today=new Date().toLocaleDateString("en-CA");if(state.lastDaily===today){toast("Вы уже забрали сегодняшний бонус. Возвращайтесь завтра!");return;}state.lastDaily=today;changeBalance(500,"Ежедневный бонус");$("#dailyStatus").textContent="Бонус получен! Следующий доступен завтра.";$("#dailyClaim").textContent="Бонус получен ✓";$("#dailyClaim").disabled=true;toast("Вам начислено ₽ 500 виртуальных очков!");}
  const rnd=(a,b)=>Math.floor(Math.random()*(b-a+1))+a;
  function openGame(game){
    let stake=100, resultText="Выберите действие, чтобы начать.", stageIcon=game.icon, controls="";
    const config={
      "Слоты":{buttons:["Крутить"],run:()=>{const s=["🍒","🔔","7️⃣","💎","🍋"];let a=s[rnd(0,s.length-1)],b=s[rnd(0,s.length-1)],c=s[rnd(0,s.length-1)];let win=a===b&&b===c?500:a===b||b===c||a===c?150:0;return {icon:`${a} ${b} ${c}`,text:win?`Комбинация! +${money(win)}`:"В этот раз без совпадений.",win};}},
      "Рулетка":{buttons:["Красное","Чёрное","Зелёное"],run:(choice)=>{let n=rnd(0,36),color=n===0?"Зелёное":n%2?"Красное":"Чёрное";let win=choice===color?(color==="Зелёное"?1200:200):0;return{icon:`${n}`,text:`${color}. ${win?"Вы угадали! +"+money(win):"Попробуйте ещё раз."}`,win};}},
      "Блэкджек":{buttons:["Взять карту","Стоп"],run:(choice,ctx)=>{if(choice==="Взять карту"){ctx.total+=rnd(1,11);return{icon:`🂠 ${ctx.total}`,text:ctx.total>21?"Перебор! Раунд завершён.":`У вас ${ctx.total}. Взять ещё или остановиться?`,win:ctx.total>21?0:null};}let total=ctx.total;let win=total>=17&&total<=21?200:0;return{icon:`${total} против ${rnd(15,22)}`,text:win?"Хорошая рука! +"+money(win):"Дилер сильнее в этом раунде.",win};}},
      "Кости":{buttons:["Бросить кости"],run:()=>{let a=rnd(1,6),b=rnd(1,6),win=a+b>=9?200:0;return{icon:`🎲 ${a} + ${b}`,text:`Сумма ${a+b}. ${win?"Отличный бросок! +"+money(win):"Нужна сумма 9 или выше."}`,win};}},
      "Мины":{buttons:["Открыть клетку"],run:()=>{let safe=Math.random()>.28;return{icon:safe?"💎":"💣",text:safe?"Безопасно! +₽ 150":"Мина! Ставка раунда потеряна.",win:safe?150:0};}},
      "Plinko":{buttons:["Бросить фишку"],run:()=>{let n=[0,50,100,150,300,500][rnd(0,5)];return{icon:"🔻",text:n?`Фишка принесла ${money(n)}!`:"Фишка в пустом слоте.",win:n};}},
      "Покер":{buttons:["Раздать карты"],run:()=>{let ranks=["A","K","Q","J","10","9"],suits=["♠","♥","♦","♣"];let hand=Array.from({length:5},()=>ranks[rnd(0,5)]+suits[rnd(0,3)]);let win=200;return{icon:hand.join("  "),text:"Демо-раздача завершена. Условный приз за участие: +₽ 200",win};}},
      "Дракон и тигр":{buttons:["Открыть карты"],run:()=>{let a=rnd(1,13),b=rnd(1,13),win=a===b?100:a>b?200:0;return{icon:`🐉 ${a}  ·  ${b} 🐅`,text:a===b?"Ничья! +₽ 100":win?"Дракон победил! +₽ 200":"Тигр победил в этом раунде.",win};}},
      "Crash":{buttons:["Запустить"],run:()=>{let x=(1+Math.random()*3).toFixed(2),win=Number(x)>1.7?Math.round(100*Number(x)):0;return{icon:`${x}×`,text:win?`Успешный демо-взлёт: +${money(win)}`:"Множитель упал слишком рано.",win};}},
      "Chicken Road":{buttons:["Перейти дорогу"],run:()=>{let safe=Math.random()>.35;return{icon:safe?"🐔 ➜ 🌟":"🐔 💨",text:safe?"Путь пройден! +₽ 150":"Попробуйте перейти ещё раз.",win:safe?150:0};}},
      "Скачки":{buttons:["Начать забег"],run:()=>{let n=rnd(1,5),win=n===1?300:0;return{icon:`🏇 Финиш: №${n}`,text:win?"Ваш фаворит выиграл! +₽ 300":"Победила другая лошадь.",win};}},
      "Дартс":{buttons:["Бросить дротик"],run:()=>{let n=rnd(1,10),win=n>=7?200:0;return{icon:`🎯 ${n}/10`,text:win?"Попадание! +₽ 200":"Попробуйте прицелиться точнее.",win};}},
      "Сундуки удачи":{buttons:["Открыть сундук"],run:()=>{let n=[0,100,200,500][rnd(0,3)];return{icon:n?"🧰 ✨":"🧰",text:n?`В сундуке ${money(n)}!`:"Сундук пуст. Удача ждёт впереди.",win:n};}},
      "Орёл или решка":{buttons:["Орёл","Решка"],run:(c)=>{let side=Math.random()>.5?"Орёл":"Решка",win=c===side?200:0;return{icon:side==="Орёл"?"🦅":"🪙",text:`Выпало: ${side}. ${win?"Угадали! +₽ 200":"Не угадали."}`,win};}},
      "Колесо фортуны":{buttons:["Крутить колесо"],run:()=>{let n=[0,100,200,300,500][rnd(0,4)];return{icon:"☸️",text:n?`Сектор ${money(n)}!`:"Пустой сектор. Крутите снова.",win:n};}},
      "Баккара":{buttons:["Раздать"],run:()=>{let p=rnd(0,9),b=rnd(0,9),win=p>b?200:p===b?100:0;return{icon:`♙ ${p}  ·  ${b} ♟`,text:p===b?"Ничья! +₽ 100":win?"Победа игрока! +₽ 200":"Победил банкир.",win};}},
      "Угадай число":{buttons:["Угадать"],run:(c)=>{let n=rnd(1,6),guess=Number(c)||rnd(1,6),win=n===guess?500:0;return{icon:`🔢 ${n}`,text:`Загаданное число: ${n}. ${win?"Точно! +₽ 500":"Не совпало."}`,win};}},
      "Охота за драгоценностями":{buttons:["Найти камень"],run:()=>{let n=rnd(0,4),win=n*100;return{icon:["💎","💚","🔷","🔶","✨"][rnd(0,4)],text:win?`Найдено сокровище: +${money(win)}.`:"Камень оказался обычным.",win};}},
      "Боулинг":{buttons:["Бросить шар"],run:()=>{let n=rnd(0,10),win=n>=7?200:0;return{icon:`🎳 ${n} кеглей`,text:win?"Страйк почти рядом! +₽ 200":`Сбито кеглей: ${n}. Ещё попытка?`,win};}},
      "Счастливая семёрка":{buttons:["Проверить удачу"],run:()=>{let n=rnd(1,10),win=n===7?700:n===3?100:0;return{icon:`${n}️⃣`,text:win?`Счастливое число! +${money(win)}`:"Сегодня число не совпало.",win};}}
    };
    const gameConfig=config[game.name]||config["Кости"];
    const ctx={total:0};
    function draw(){openModal(game.name,`<p>${escapeHtml(game.desc)} Все результаты случайны и используются только для демонстрации механики.</p><div class="game-stage"><div class="stage-symbol" id="stageSymbol">${stageIcon}</div><div class="stage-result" id="stageResult">${escapeHtml(resultText)}</div><div class="stage-help">Раунд без реальных ставок · цена действия: 100 очков</div></div><div class="game-controls">${gameConfig.buttons.map(b=>`<button data-action="${escapeHtml(b)}">${escapeHtml(b)}</button>`).join("")}</div>${game.name==="Угадай число"?`<label class="form-label" for="guessInput">Ваше число от 1 до 6</label><input class="field" id="guessInput" type="number" min="1" max="6" value="3">`:""}<div class="game-controls"><button id="gameClose">Выйти из игры</button></div>${modalBalance()}`);
      $("#gameClose").onclick=closeModal;
      $("#modalContent").querySelectorAll("[data-action]").forEach(btn=>btn.onclick=()=>play(btn.dataset.action));
    }
    function play(choice){
      if(!changeBalance(-100,`Раунд: ${game.name}`))return;
      let actualChoice=choice;
      if(game.name==="Угадай число")actualChoice=$("#guessInput").value;
      const out=gameConfig.run(actualChoice,ctx);
      $("#stageSymbol").textContent=out.icon;$("#stageResult").textContent=out.text;
      if(out.win===null){updateBalance();return;}
      if(out.win>0){state.balance+=out.win;state.wins=(state.wins||0)+1;state.history.unshift({type:`Приз: ${game.name}`,amount:out.win,date:new Date().toISOString()});}
      state.played=(state.played||0)+1;state.history=state.history.slice(0,40);save();
      const bal=$("#modalContent .modal-balance");if(bal)bal.innerHTML=`Баланс: <strong>${money(state.balance)}</strong> · виртуальные очки`;
    }
    if(game.name==="Блэкджек")ctx.total=rnd(10,16);
    draw();
  }
  $("#filters").addEventListener("click",e=>{const b=e.target.closest("[data-category]");if(!b)return;activeCategory=b.dataset.category;$("#filters").querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));renderGames();});
  $("#gameSearch").addEventListener("input",renderGames);
  $("#depositBtn").onclick=()=>openWallet("deposit");$("#withdrawBtn").onclick=()=>openWallet("withdraw");$("#historyBtn").onclick=openHistory;$("#profileBtn").onclick=openProfile;
  $("#dailyClaim").onclick=claimDaily;$("#bonusHero").onclick=()=>{document.querySelector("#daily").scrollIntoView({behavior:"smooth"});claimDaily();};
  $("#modalClose").onclick=closeModal;$("#modalBackdrop").addEventListener("click",e=>{if(e.target===$("#modalBackdrop"))closeModal();});
  document.addEventListener("keydown",e=>{if(e.key==="Escape"&&!$("#modalBackdrop").hidden)closeModal();});
  $("#menuBtn").onclick=()=>{const nav=$(".desktop-nav");if(getComputedStyle(nav).display==="none"){nav.style.display="flex";nav.style.position="absolute";nav.style.top="71px";nav.style.left="0";nav.style.right="0";nav.style.padding="18px 24px";nav.style.background="#10100e";nav.style.borderBottom="1px solid #333";nav.style.zIndex="30";nav.style.justifyContent="center";}else nav.removeAttribute("style");};
  function refreshDaily(){const today=new Date().toLocaleDateString("en-CA");if(state.lastDaily===today){$("#dailyStatus").textContent="Вы уже забрали бонус сегодня. Возвращайтесь завтра." ;$("#dailyClaim").textContent="Бонус получен ✓";$("#dailyClaim").disabled=true;}}
  updateBalance();renderGames();renderLeaders();refreshDaily();
})();